import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import fands.Employee;

public class EmployeeManagerTest {
	private EmployeeManager mgr;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception{
		
	}
	@Before
	public void setUp() throws Exception{
		System.out.print("Setup");
		mgr = new EmployeeManager();
	}
	@Test
	public void testAdd(){
		Employee e = new Employee();
		e.setEmpno(1);e.setSalary(1111);e.setEname("A");
		mgr.add(e);
		
		if(mgr.l1.size()!=1)
			fail("Emp item not added");
		if(mgr.l1.get(0)!=e)
			fail("Employee object not added correctly");
		
	}
	@Test
	public void testList() {
		//fail("Not yet implemented");
	}

}
