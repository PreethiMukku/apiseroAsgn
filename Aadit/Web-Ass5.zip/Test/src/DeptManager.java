class Dept{
	private int deptno;
	String dname,location;
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	@Override
	public String toString() {
		return "Dept [deptno=" + deptno + ", dname=" + dname + ", location=" + location + "]";
	}
	
}

public class DeptManager {
	private Dept[] dep = new Dept[5];
	public void modify(int i,Dept d){
	}
	public static void main(String args[]){
		DeptManager deptman = new DeptManager();
		Dept d = new Dept();
		d.setDeptno(1);
		d.setDname("IT");
		d.setLocation("Mum");
		Dept d = new Dept();
		d.setDeptno(2);
		d.setDname("HR");
		d.setLocation("Ban");
		Dept d = new Dept();
		d.setDeptno(3);
		d.setDname("Recr");
		d.setLocation("Kolk");
		Dept d = new Dept();
		d.setDeptno(4);
		d.setDname("Mark");
		d.setLocation("Delhi");
		Dept d = new Dept();
		d.setDeptno(5);
		d.setDname("IT");
		d.setLocation("Mum");
	}
}
