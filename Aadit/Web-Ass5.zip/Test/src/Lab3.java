import java.util.Scanner;

public class Lab3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please enter the number for the series");
		int num = scanner.nextInt();
		int a =0,b=1,sum=0;
		System.out.println(a);
		System.out.println(b);
		for (int i=0;i<num-2;i++){
			sum = a+b;
			System.out.println(sum);
			a=b;
			b = sum;
		}
	}

}
