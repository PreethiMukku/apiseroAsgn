//import java.util.Arrays;
//import java.util.Scanner;
//
//public class Lab4 {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		System.out.println("Enter 5 strings");
//		String[] mystring = new String[5];
//		Scanner scanner = new Scanner(System.in);
//		int sum = 0;
//		for(int i=0;i<mystring.length;i++){
//			mystring[i] = scanner.next();
//			sum += mystring[i].length(); 
//		}
//		System.out.println("The strings are"+Arrays.toString(mystring));
//		System.out.println("The average is "+sum/5);
//	}
//
//}
interface Sort {
	public void dosort();
}
class Bubble implements Sort{
	@Override
	public void dosort() {
		System.out.println("Bubble - dosort");
		
	}
}
class Shell implements Sort{
	@Override
	public void dosort() {
		System.out.println("Shell - dosort");
		
	}
	
	
}
public class Lab4 {

	public static void main(String[] args) {
		String ch ="b";
		Sort sort = null;
		if (ch.equals("b"))
			sort = new Bubble();
		else
			 sort  = new Shell();
		sort.dosort();
	}

}
