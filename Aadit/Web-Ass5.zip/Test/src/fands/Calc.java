package fands;
public class Calc {
	public static int add(int i, int j){
		int addition;
		addition = i+j;
		return addition;
	}
}
