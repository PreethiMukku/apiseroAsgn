import fands.Calc;
public class Lab1 {
	public static void main(String args[]){
		int addition;
		System.out.println("Hello World");
		Calc cls = new Calc();
		addition = cls.add(10, 20);
		System.out.println(addition);
	}
}


