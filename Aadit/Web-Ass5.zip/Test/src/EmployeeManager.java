import java.awt.List;
import java.util.ArrayList;

import fands.Employee;

public class EmployeeManager {
	ArrayList<Employee> l1 = new ArrayList();
	
	public void add(Employee e){
		l1.add(e);
		System.out.print(l1);
	}
	
	public static void main(String args[]){
		//ArrayList<Employee> l1 = new ArrayList();
		EmployeeManager mgr = new EmployeeManager();
		Employee e = new Employee();
		e.setEmpno(1);
		e.setEname("Aadit");
		e.setSalary(100);
		mgr.add(e);
		//l1.add(e);
		//Employee e = new Employee();
		e.setEmpno(2);
		e.setEname("Karthik");
		e.setSalary(200);
		mgr.add(e);
		//l1.add(e);
		//e.toString();
		//System.out.println(l1);
		
		//add(e);
		//add(Employee e);
	}
}
